Step 1 : Download the Wireshark
Step 2 : execute command C:\Program Files\Wireshark\Wireshark.exe -X lua_script:{tools path}\mipc.lua {log path}\{log name}.cap
Remember to change "C:\Program Files\Wireshark\Wireshark.exe" to your Wireshark path if needed
